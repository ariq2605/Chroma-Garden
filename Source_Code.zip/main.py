import customtkinter as ctk
from PIL import ImageGrab, ImageTk, Image, ImageDraw, ImageFont
import pyperclip
from pynput import mouse
import threading
import sqlite3
import tkinter as tk
import colorsys
import ctypes
import os

# --- DPI AWARENESS ---
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(1)
except:
    pass

class MagnifierOverlay(tk.Toplevel):
    def __init__(self, full_screen_img, callback):
        super().__init__()
        self.full_screen_img = full_screen_img
        self.callback = callback
        self.overrideredirect(True)
        self.attributes("-topmost", True)
        self.trans_key = "#010101"
        self.attributes("-transparentcolor", self.trans_key)
        self.size = 220
        self.canvas = tk.Canvas(self, width=self.size, height=self.size, bg=self.trans_key, highlightthickness=0)
        self.canvas.pack()
        self.update_loop()

    def update_loop(self):
        try:
            x, y = self.winfo_pointerxy()
            self.geometry(f"+{int(x - self.size//2)}+{int(y - self.size//2)}")
            r = 15
            screenshot = self.full_screen_img.crop((x - r, y - r, x + r, y + r))
            zoom_img = screenshot.resize((self.size, self.size), Image.Resampling.NEAREST)
            self.current_img = ImageTk.PhotoImage(zoom_img)
            self.canvas.delete("all")
            self.canvas.create_image(self.size//2, self.size//2, image=self.current_img)
            self.canvas.create_oval(5, 5, self.size-5, self.size-5, outline="white", width=3)
            mid = self.size // 2
            self.canvas.create_line(mid, mid-20, mid, mid+20, fill="#00FF00", width=2)
            self.canvas.create_line(mid-20, mid, mid+20, mid, fill="#00FF00", width=2)
            self.after(10, self.update_loop)
        except: self.destroy()

    def on_click_event(self, x, y):
        rgb = self.full_screen_img.getpixel((x, y))
        self.destroy()
        self.callback(rgb)

class ChromaGarden(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.conn = sqlite3.connect('garden_history.db')
        self.cursor = self.conn.cursor()
        self.cursor.execute('CREATE TABLE IF NOT EXISTS colors (hex TEXT, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)')
        self.conn.commit()

        self.title("Chroma Garden v1.1")
        self.geometry("1100x650")
        self.configure(fg_color="#050505")
        self.current_rgb = (0, 0, 0)

        # Main UI
        self.main_display = ctk.CTkFrame(self, corner_radius=30, fg_color="#0d0d0d", border_width=1, border_color="#222")
        self.main_display.pack(padx=30, pady=(60, 20), fill="both", expand=True)

        self.glow_frame = ctk.CTkFrame(self.main_display, fg_color="transparent")
        self.glow_frame.place(relx=0.5, rely=0.45, anchor="center")
        
        self.glow_main = ctk.CTkLabel(self.glow_frame, text="✧", font=("Inter", 380), text_color="#111")
        self.glow_main.grid(row=0, column=1)
        self.glow_comp = ctk.CTkLabel(self.glow_frame, text="✦", font=("Inter", 160), text_color="#111")
        self.glow_comp.grid(row=0, column=0, padx=20)
        self.glow_ana = ctk.CTkLabel(self.glow_frame, text="✦", font=("Inter", 160), text_color="#111")
        self.glow_ana.grid(row=0, column=2, padx=20)
        
        self.sidebar = ctk.CTkFrame(self, fg_color="transparent")
        self.sidebar.place(x=50, y=100)
        self.history_scroll = ctk.CTkScrollableFrame(self.sidebar, fg_color="transparent", width=80, height=350)
        self.history_scroll.pack(pady=10)

        # Dock
        self.dock = ctk.CTkFrame(self, fg_color="#FFFFFF", height=100, corner_radius=0)
        self.dock.pack(side="bottom", fill="x")

        self.hex_label = ctk.CTkLabel(self.dock, text="#------", text_color="black", font=("Courier New", 45, "bold"))
        self.hex_label.pack(side="left", padx=40)

        self.btn_frame = ctk.CTkFrame(self.dock, fg_color="transparent")
        self.btn_frame.pack(side="right", padx=40)

        self.save_btn = ctk.CTkButton(self.btn_frame, text="SAVE PNG", fg_color="#EEE", text_color="black", hover_color="#CCC", corner_radius=0, width=120, height=50, font=("Inter", 14, "bold"), command=self.export_palette)
        self.save_btn.pack(side="left", padx=10)

        self.scan_btn = ctk.CTkButton(self.btn_frame, text="SCAN PIXEL", fg_color="black", text_color="white", hover_color="#333", corner_radius=0, width=180, height=50, font=("Inter", 16, "bold"), command=self.initiate_scan)
        self.scan_btn.pack(side="left")

        self.load_history()

    def initiate_scan(self):
        self.withdraw()
        self.after(250, self._capture_and_start)

    def _capture_and_start(self):
        full_img = ImageGrab.grab(all_screens=True)
        overlay = MagnifierOverlay(full_img, self.finalize_pick)
        def on_click(x, y, button, pressed):
            if pressed:
                self.after(0, lambda: overlay.on_click_event(int(x), int(y)))
                return False
        threading.Thread(target=lambda: mouse.Listener(on_click=on_click).start(), daemon=True).start()

    def generate_palette(self, rgb):
        h, l, s = colorsys.rgb_to_hls(rgb[0]/255, rgb[1]/255, rgb[2]/255)
        c_h = (h + 0.5) % 1.0
        c_rgb = colorsys.hls_to_rgb(c_h, l, s)
        c_hex = '#{:02x}{:02x}{:02x}'.format(int(c_rgb[0]*255), int(c_rgb[1]*255), int(c_rgb[2]*255))
        a_h = (h + 0.1) % 1.0
        a_rgb = colorsys.hls_to_rgb(a_h, l, s)
        a_hex = '#{:02x}{:02x}{:02x}'.format(int(a_rgb[0]*255), int(a_rgb[1]*255), int(a_rgb[2]*255))
        return c_hex, a_hex

    def finalize_pick(self, rgb):
        self.current_rgb = rgb
        hex_code = '#{:02x}{:02x}{:02x}'.format(*rgb).upper()
        self.cursor.execute('INSERT INTO colors (hex) VALUES (?)', (hex_code,))
        self.conn.commit()
        pyperclip.copy(hex_code)
        comp, ana = self.generate_palette(rgb)
        self.apply_ui_colors(hex_code, comp, ana)
        self.load_history()
        self.deiconify()

    def apply_ui_colors(self, main, comp, ana):
        self.hex_label.configure(text=main)
        self.glow_main.configure(text_color=main)
        self.glow_comp.configure(text_color=comp)
        self.glow_ana.configure(text_color=ana)
        self.main_display.configure(border_color=main)
        # Update current RGB for potential export
        self.current_rgb = tuple(int(main.lstrip('#')[i:i+2], 16) for i in (0, 2, 4))

    def export_palette(self):
        main_hex = '#{:02x}{:02x}{:02x}'.format(*self.current_rgb).upper()
        comp_hex, ana_hex = self.generate_palette(self.current_rgb)
        
        # Create Image
        img = Image.new('RGB', (1200, 600), color='#050505')
        draw = ImageDraw.Draw(img)
        
        colors = [main_hex, comp_hex, ana_hex]
        labels = ["PRIMARY", "COMPLEMENTARY", "ANALOGOUS"]
        
        for i, color in enumerate(colors):
            x0 = i * 400
            draw.rectangle([x0, 0, x0 + 400, 500], fill=color)
            draw.text((x0 + 20, 520), f"{labels[i]}\n{color}", fill="white")

        filename = f"palette_{main_hex.replace('#','')}.png"
        img.save(filename)
        os.startfile(filename) # Auto-open on Windows

    def load_history(self):
        self.cursor.execute('SELECT hex FROM colors ORDER BY timestamp DESC LIMIT 30')
        rows = self.cursor.fetchall()
        for widget in self.history_scroll.winfo_children(): widget.destroy()
        for row in rows:
            btn = ctk.CTkButton(self.history_scroll, text="", fg_color=row[0], width=45, height=45, corner_radius=22, border_width=2, border_color="#1a1a1a", 
                                command=lambda h=row[0]: self.apply_ui_colors(h, *self.generate_palette(tuple(int(h.lstrip('#')[i:i+2], 16) for i in (0, 2, 4)))))
            btn.pack(pady=8)

if __name__ == "__main__":
    app = ChromaGarden()
    app.mainloop()